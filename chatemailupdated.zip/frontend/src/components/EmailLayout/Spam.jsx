import React from 'react'

const Spam = () => {
  return (
    <div>
      Spam
    </div>
  )
}

export default Spam
